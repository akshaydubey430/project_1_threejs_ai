import ai from "./ai.png";
import fileIcon from "./file.png";
import swatch from "./swatch.png";
import download from "./download.png";

import logoShirt from "./logo-tshirt.png";
import stylishShirt from "./stylish-tshirt.png";

export { ai, fileIcon, swatch, download, logoShirt, stylishShirt };
